#!/bin/bash
cd /home/devbox/project
npm run start