<template>
  <div class="app-container" :class="{ 'dark-mode': isDarkMode }">
    <aside class="sidebar" :class="{ 'collapsed': isSidebarCollapsed }">
      <div class="logo-container">
        <img src="@/assets/logo.svg" alt="Logo" class="logo">
      </div>

      <nav class="nav-menu">
        <router-link to="/" class="nav-item" exact-active-class="active">
          <el-icon>
            <DataLine />
          </el-icon>
          <span v-show="!isSidebarCollapsed">仪表盘</span>
        </router-link>
        <router-link to="/files" class="nav-item" exact-active-class="active">
          <el-icon>
            <Folder />
          </el-icon>
          <span v-show="!isSidebarCollapsed">文件管理</span>
        </router-link>
        <router-link to="/profile" class="nav-item" exact-active-class="active">
          <el-icon>
            <User />
          </el-icon>
          <span v-show="!isSidebarCollapsed">个人信息</span>
        </router-link>
      </nav>

      <div class="sidebar-footer">
        <div class="footer-buttons">
          <el-button class="theme-toggle" @click="toggleTheme" :icon="isDarkMode ? 'Sunny' : 'Moon'" circle />
          <el-button class="logout-button" type="danger" @click="handleLogout" :icon="SwitchButton"
            :title="isSidebarCollapsed ? '退出登录' : ''">
            <span v-show="!isSidebarCollapsed">退出登录</span>
          </el-button>
        </div>
      </div>
    </aside>

    <div class="main-content">
      <header class="top-header">
        <div class="header-left">
          <el-button class="sidebar-toggle" @click="toggleSidebar" :icon="isSidebarCollapsed ? 'Expand' : 'Fold'"
            circle />
          <div class="header-title">
            {{ currentRoute.meta.title }}
          </div>
        </div>
        <div class="header-right">
          <div class="header-tools">
            <!-- 全局搜索 -->
            <el-popover placement="bottom" :width="400" trigger="click" popper-class="search-popover">
              <template #reference>
                <el-button :icon="Search" circle v-tooltip="'全局搜索'" />
              </template>
              <div class="global-search">
                <el-input v-model="searchKeyword" placeholder="搜索文件、文档..." :prefix-icon="Search" @input="handleSearch"
                  clearable>
                  <template #append>
                    <el-button type="primary">搜索</el-button>
                  </template>
                </el-input>
                <div class="search-result" v-if="searchResults.length > 0">
                  <div v-for="item in searchResults" :key="item.id" class="result-item"
                    @click="handleResultClick(item)">
                    <el-icon>
                      <component :is="item.icon" />
                    </el-icon>
                    <div class="item-info">
                      <div class="title">{{ item.title }}</div>
                      <div class="path">{{ item.path }}</div>
                    </div>
                  </div>
                </div>
              </div>
            </el-popover>

            <!-- 通知中心 -->
            <el-popover placement="bottom" :width="350" trigger="click" popper-class="notification-popover">
              <template #reference>
                <el-badge :value="unreadCount" :max="99" class="notification-badge">
                  <el-button :icon="Bell" circle v-tooltip="'通知中心'" />
                </el-badge>
              </template>
              <div class="notification-panel">
                <div class="panel-header">
                  <span>通知中心</span>
                  <el-button link type="primary" @click="markAllRead">全部已读</el-button>
                </div>
                <el-tabs v-model="activeTab">
                  <el-tab-pane label="全部" name="all">
                    <div class="notification-list">
                      <div v-for="notice in notifications" :key="notice.id" class="notification-item"
                        :class="{ unread: !notice.read }" @click="handleNotificationClick(notice)">
                        <el-icon :class="notice.type">
                          <component :is="getNoticeIcon(notice.type)" />
                        </el-icon>
                        <div class="notice-content">
                          <div class="notice-title">{{ notice.title }}</div>
                          <div class="notice-time">{{ notice.time }}</div>
                        </div>
                      </div>
                    </div>
                  </el-tab-pane>
                  <el-tab-pane label="未读" name="unread">
                    <div class="notification-list">
                      <div v-for="notice in unreadNotifications" :key="notice.id" class="notification-item unread"
                        @click="handleNotificationClick(notice)">
                        <el-icon :class="notice.type">
                          <component :is="getNoticeIcon(notice.type)" />
                        </el-icon>
                        <div class="notice-content">
                          <div class="notice-title">{{ notice.title }}</div>
                          <div class="notice-time">{{ notice.time }}</div>
                        </div>
                      </div>
                    </div>
                  </el-tab-pane>
                </el-tabs>
              </div>
            </el-popover>
          </div>
        </div>
      </header>

      <main class="content-area">
        <div class="content-wrapper">
          <router-view v-slot="{ Component }">
            <transition name="fade" mode="out-in">
              <component :is="Component" />
            </transition>
          </router-view>
        </div>
      </main>
    </div>
  </div>

  <!-- 设置对话框 -->
  <el-dialog v-model="showSettings" title="系统设置" width="600px" class="settings-dialog">
    <el-tabs>
      <el-tab-pane label="界面设置">
        <div class="settings-section">
          <div class="setting-item">
            <span class="label">深色模式</span>
            <el-switch v-model="isDarkMode" @change="toggleTheme" />
          </div>
          <div class="setting-item">
            <span class="label">侧边栏收起</span>
            <el-switch v-model="isSidebarCollapsed" @change="toggleSidebar" />
          </div>
          <div class="setting-item">
            <span class="label">主题色</span>
            <el-color-picker v-model="themeColor" />
          </div>
        </div>
      </el-tab-pane>

      <el-tab-pane label="通知设置">
        <div class="settings-section">
          <div class="setting-item">
            <span class="label">系统通知</span>
            <el-switch v-model="notificationSettings.system" />
          </div>
          <div class="setting-item">
            <span class="label">文件更新提醒</span>
            <el-switch v-model="notificationSettings.fileUpdates" />
          </div>
          <div class="setting-item">
            <span class="label">声音提醒</span>
            <el-switch v-model="notificationSettings.sound" />
          </div>
        </div>
      </el-tab-pane>

      <el-tab-pane label="存储设置">
        <div class="settings-section">
          <div class="storage-info">
            <el-progress type="dashboard" :percentage="storageUsage" />
            <div class="storage-text">
              <div>已使用12.5GB</div>
              <div>总容量：50GB</div>
            </div>
          </div>
          <el-alert v-if="storageUsage > 80" type="warning" :closable="false" show-icon>
            存储空间即将用完，请及时清理
          </el-alert>
        </div>
      </el-tab-pane>
    </el-tabs>

    <template #footer>
      <div class="dialog-footer">
        <el-button @click="showSettings = false">取消</el-button>
        <el-button type="primary" @click="saveSettings">
          存设置
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import {
  DataLine,
  Folder,
  Search,
  Bell,
  User,
  Setting,
  SwitchButton,
  InfoFilled,
  WarningFilled,
  SuccessFilled
} from '@element-plus/icons-vue'
import { ElMessage, ElProgress, ElAlert, ElMessageBox } from 'element-plus'
import { useUserStore } from '@/stores/user'

const isDarkMode = ref(false)
const isSidebarCollapsed = ref(false)
const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

const currentRoute = computed(() => route)

const toggleTheme = () => {
  isDarkMode.value = !isDarkMode.value
  document.documentElement.classList.toggle('dark')
}

const toggleSidebar = () => {
  isSidebarCollapsed.value = !isSidebarCollapsed.value
}

const userInfo = ref({
  name: '管理员',
  email: 'admin@example.com',
  role: '系统管理员'
})

const handleCommand = (command) => {
  switch (command) {
    case 'profile':
      router.push('/profile')
      break
    case 'settings':
      showSettings.value = true
      break
    case 'logout':
      ElMessage.success('退出登录成功')
      break
  }
}

// 搜索相关
const searchKeyword = ref('')
const searchResults = ref([])

const handleSearch = (value) => {
  // 模拟搜索果
  if (value) {
    searchResults.value = [
      { id: 1, title: '项目方案.pdf', path: '/files/项目方案.pdf', icon: Document },
      { id: 2, title: '会议记录', path: '/files/会议记录', icon: Folder },
      { id: 3, title: '数据分析报告', path: '/files/数据分析报告.xlsx', icon: Document }
    ]
  } else {
    searchResults.value = []
  }
}

const handleResultClick = (item) => {
  ElMessage.success(`正在打开: ${item.title}`)
  // 这里可以添加导航逻辑
}

// 通知相关
const activeTab = ref('all')
const unreadCount = ref(3)
const notifications = ref([
  {
    id: 1,
    title: '新文件上传成功',
    time: '10分钟前',
    type: 'success',
    read: false
  },
  {
    id: 2,
    title: '系统更新提醒',
    time: '1小时前',
    type: 'info',
    read: false
  },
  {
    id: 3,
    title: '存储空间警告',
    time: '2小时前',
    type: 'warning',
    read: false
  }
])

const unreadNotifications = computed(() =>
  notifications.value.filter(notice => !notice.read)
)

const getNoticeIcon = (type) => {
  const icons = {
    success: SuccessFilled,
    warning: WarningFilled,
    info: InfoFilled
  }
  return icons[type] || InfoFilled
}

const handleNotificationClick = (notice) => {
  notice.read = true
  unreadCount.value = unreadNotifications.value.length
  ElMessage.success(`查看通知: ${notice.title}`)
}

const markAllRead = () => {
  notifications.value.forEach(notice => notice.read = true)
  unreadCount.value = 0
  ElMessage.success('已将所有通知标记为已读')
}

const showSettings = ref(false)
const themeColor = ref('#007AFF')
const notificationSettings = ref({
  system: true,
  fileUpdates: true,
  sound: false
})
const storageUsage = ref(85)

const saveSettings = () => {
  ElMessage.success('设置保存成功')
  showSettings.value = false
}

const handleLogout = () => {
  ElMessageBox.confirm(
    '确定要退出登录吗？',
    '提示',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  ).then(() => {
    userStore.logout()
    router.push('/login')
    ElMessage.success('退出登录成功')
  }).catch(() => {})
}

onMounted(async () => {
  if (userStore.token) {
    try {
      await userStore.getUserInfo()
    } catch (error) {
      console.error('获取用户信息失败:', error)
    }
  }
})
</script>

<style lang="scss">
@use "sass:math";

.app-container {
  display: flex;
  min-height: 100vh;
  background: var(--el-bg-color);
  transition: background-color 0.3s;
  width: 100%;
}

.sidebar {
  width: 260px;
  min-height: 100vh;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-right: 1px solid rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  transition: all 0.3s;
  position: fixed;
  left: 0;
  top: 0;
  bottom: 0;
  z-index: 1000;

  &.collapsed {
    width: 80px;
  }

  .sidebar-footer {
    padding: 1rem;
    border-top: 1px solid var(--el-border-color-lighter);

    .footer-buttons {
      display: flex;
      flex-direction: column;
      gap: 0.8rem;
      align-items: center;

      .theme-toggle {
        margin: 0;
      }

      .logout-button {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;

        .el-icon {
          margin-right: 0;
          font-size: 16px;
        }

        span {
          font-size: 0.9rem;
        }
      }
    }
  }
}

.logo-container {
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 1rem;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);

  .logo {
    height: 36px;
  }
}

.nav-menu {
  flex: 1;
  padding: 1rem 0;

  .nav-item {
    display: flex;
    align-items: center;
    padding: 0.8rem 1.5rem;
    color: var(--el-text-color-primary);
    text-decoration: none;
    transition: all 0.3s;
    margin: 0.2rem 0.8rem;
    border-radius: 8px;

    &:hover {
      background: rgba(0, 0, 0, 0.05);
    }

    &.active {
      background: var(--el-color-primary-light-9);
      color: var(--el-color-primary);
    }

    .el-icon {
      margin-right: 1rem;
      font-size: 1.2rem;
    }
  }
}

.main-content {
  position: absolute;
  left: 260px;
  right: 0;
  min-height: 100vh;
  transition: all 0.3s;
  display: flex;
  flex-direction: column;

  .sidebar.collapsed+& {
    left: 80px;
  }
}

.top-header {
  position: fixed;
  left: 260px;
  right: 0;
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 2rem;
  background: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(10px);
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  z-index: 100;
  transition: left 0.3s;

  .sidebar.collapsed+.main-content & {
    left: 80px;
  }

  .header-left {
    display: flex;
    align-items: center;
    gap: 1rem;

    .header-title {
      font-size: 1.2rem;
      font-weight: 500;
    }
  }

  .header-right {
    display: flex;
    align-items: center;
    gap: 1rem;

    .el-dropdown {
      cursor: pointer;
    }
  }
}

.content-area {
  margin-top: 64px;
  flex: 1;
  padding: 2rem;
  background: var(--el-bg-color);
  min-height: calc(100vh - 64px);
  overflow-y: auto;
}

.content-wrapper {
  width: 100%;
  height: 100%;
  margin: 0 auto;
}

// 动画
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

// 深色模式样式
.dark-mode {

  .sidebar,
  .top-header {
    background: rgba(30, 30, 30, 0.8);
    border-color: rgba(255, 255, 255, 0.1);
  }
}

// 响应式布局
@media (max-width: 1400px) {
  .content-wrapper {
    max-width: 100%;
  }
}

@media (max-width: 1200px) {
  .main-content {
    left: 220px;

    .sidebar.collapsed+& {
      left: 70px;
    }
  }

  .top-header {
    left: 220px;

    .sidebar.collapsed+.main-content & {
      left: 70px;
    }
  }
}

@media (max-width: 768px) {
  .main-content {
    left: 0;
    width: 100%;
  }

  .top-header {
    left: 0;
    width: 100%;
  }
}

.user-info-header {
  padding: 12px 20px;
  width: 300px;

  .user-info {
    display: flex;
    align-items: center;
    gap: 1rem;

    .info-detail {
      h4 {
        margin: 0;
        font-size: 1rem;
        color: var(--el-text-color-primary);
      }

      p {
        margin: 4px 0 0;
        font-size: 0.875rem;
        color: var(--el-text-color-secondary);
      }
    }
  }
}

.el-dropdown-menu__item {
  display: flex;
  align-items: center;
  gap: 0.5rem;

  .el-icon {
    margin-right: 0.25rem;
  }

  &.danger {
    color: var(--el-color-danger);
  }
}

.header-tools {
  display: flex;
  gap: 0.5rem;
}

.search-popover {
  padding: 0;

  .global-search {
    .el-input {
      margin-bottom: 1rem;
    }

    .search-result {
      max-height: 300px;
      overflow-y: auto;

      .result-item {
        display: flex;
        align-items: center;
        padding: 0.8rem 1rem;
        cursor: pointer;

        &:hover {
          background: var(--el-color-primary-light-9);
        }

        .el-icon {
          margin-right: 1rem;
          font-size: 1.2rem;
          color: var(--el-text-color-secondary);
        }

        .item-info {
          .title {
            font-size: 0.9rem;
            margin-bottom: 0.2rem;
          }

          .path {
            font-size: 0.8rem;
            color: var(--el-text-color-secondary);
          }
        }
      }
    }
  }
}

.notification-popover {
  padding: 0;

  .notification-panel {
    .panel-header {
      padding: 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid var(--el-border-color-lighter);
      background-color: var(--el-bg-color-overlay);
    }

    .el-tabs__nav-wrap {
      padding: 0 1rem;
      background-color: var(--el-bg-color-overlay);
    }

    .notification-list {
      max-height: 400px;
      overflow-y: auto;

      .notification-item {
        display: flex;
        align-items: center;
        padding: 1rem;
        cursor: pointer;
        border-bottom: 1px solid var(--el-border-color-lighter);
        background-color: var(--el-bg-color);
        transition: all 0.3s ease;

        &:hover {
          background-color: var(--el-color-primary-light-9);
        }

        &.unread {
          background-color: var(--el-bg-color-overlay);
          position: relative;

          &::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            background-color: var(--el-color-primary);
            border-radius: 0 2px 2px 0;
          }
        }

        .el-icon {
          margin-right: 1rem;
          font-size: 1.2rem;
          flex-shrink: 0;

          &.success {
            color: var(--el-color-success);
          }

          &.warning {
            color: var(--el-color-warning);
          }

          &.info {
            color: var(--el-color-info);
          }
        }

        .notice-content {
          flex: 1;
          min-width: 0;

          .notice-title {
            font-size: 0.9rem;
            margin-bottom: 0.2rem;
            color: var(--el-text-color-primary);
            font-weight: 500;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }

          .notice-time {
            font-size: 0.8rem;
            color: var(--el-text-color-secondary);
          }
        }
      }
    }

    .el-tabs__content {
      padding: 0;
    }
  }
}

.notification-badge {
  .el-badge__content {
    z-index: 101;
  }
}

.user-popover {
  padding: 0;

  .user-card {
    .user-header {
      padding: 20px;
      display: flex;
      align-items: center;
      gap: 1rem;
      border-bottom: 1px solid var(--el-border-color-lighter);

      .user-info {
        h3 {
          margin: 0;
          font-size: 1.1rem;
          font-weight: 500;
        }

        p {
          margin: 4px 0 0;
          font-size: 0.9rem;
          color: var(--el-text-color-secondary);
        }
      }
    }

    .user-stats {
      padding: 15px;
      display: flex;
      justify-content: space-around;
      border-bottom: 1px solid var(--el-border-color-lighter);

      .stat-item {
        text-align: center;

        .value {
          font-size: 1.1rem;
          font-weight: 500;
          color: var(--el-color-primary);
        }

        .label {
          font-size: 0.8rem;
          color: var(--el-text-color-secondary);
          margin-top: 4px;
        }
      }
    }

    .user-actions {
      padding: 15px;

      .action-group {
        display: flex;
        justify-content: center;
        gap: 8px;

        .el-button {
          min-width: 85px;
          padding: 8px 12px;

          .el-icon {
            margin-right: 4px;
          }

          span {
            font-size: 0.9rem;
            white-space: nowrap;
          }
        }
      }
    }
  }
}

.user-avatar {
  cursor: pointer;
  transition: transform 0.3s;

  &:hover {
    transform: scale(1.1);
  }
}

// 深色式适配
.dark-mode {
  .notification-panel {
    .notification-item {
      &:hover {
        background-color: var(--el-color-primary-light-3);
      }

      &.unread {
        background-color: rgba(var(--el-color-primary-rgb), 0.15);
      }
    }
  }
}

.settings-dialog {
  .settings-section {
    padding: 1rem;

    .setting-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 0;
      border-bottom: 1px solid var(--el-border-color-lighter);

      &:last-child {
        border-bottom: none;
      }

      .label {
        font-size: 0.95rem;
        color: var(--el-text-color-primary);
      }
    }

    .storage-info {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 2rem;
      padding: 2rem 0;

      .storage-text {
        font-size: 0.9rem;
        color: var(--el-text-color-regular);

        div {
          margin: 0.5rem 0;
        }
      }
    }
  }

  .el-alert {
    margin-top: 1rem;
  }
}

.dark {
  .settings-dialog {
    .settings-section {
      .setting-item {
        border-color: var(--el-border-color-darker);
      }
    }
  }
}
</style>