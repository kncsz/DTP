import { defineStore } from 'pinia'
// 暂时注释掉 API 导入
// import { login, register, getUserInfo } from '@/api/user'

export const useUserStore = defineStore('user', {
    state: () => ({
        token: localStorage.getItem('token') || '',
        userInfo: {}
    }),

    actions: {
        async login(data) {
            try {
                // 模拟登录成功
                const mockResponse = {
                    data: {
                        token: 'mock_token_' + Date.now(),
                        userInfo: {
                            username: data.username,
                            role: 'user'
                        }
                    }
                }

                this.token = mockResponse.data.token
                this.userInfo = mockResponse.data.userInfo
                localStorage.setItem('token', mockResponse.data.token)
                return mockResponse
            } catch (error) {
                throw error
            }
        },

        async register(data) {
            try {
                // 模拟注册成功
                return {
                    code: 200,
                    message: '注册成功'
                }
            } catch (error) {
                throw error
            }
        },

        async getUserInfo() {
            try {
                // 模拟获取用户信息
                this.userInfo = {
                    username: 'test_user',
                    role: 'user'
                }
                return {
                    code: 200,
                    data: this.userInfo
                }
            } catch (error) {
                throw error
            }
        },

        logout() {
            this.token = ''
            this.userInfo = {}
            localStorage.removeItem('token')
        }
    }
}) 