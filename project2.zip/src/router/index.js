import { createRouter, createWebHistory } from 'vue-router'

const routes = [
    {
        path: '/',
        component: () => import('@/layouts/MainLayout.vue'),
        meta: { requiresAuth: true },
        children: [
            {
                path: '',
                name: 'Dashboard',
                component: () => import('@/views/Dashboard.vue'),
                meta: { title: '仪表盘', requiresAuth: true }
            },
            {
                path: 'files',
                name: 'Files',
                component: () => import('@/views/Files.vue'),
                meta: { title: '文件管理', requiresAuth: true }
            },
            {
                path: 'profile',
                name: 'Profile',
                component: () => import('@/views/Profile.vue'),
                meta: { title: '个人信息', requiresAuth: true }
            }
        ]
    },
    {
        path: '/login',
        name: 'Login',
        component: () => import('@/views/Login.vue'),
        meta: {
            title: '登录',
            requiresAuth: false
        }
    }
]

const router = createRouter({
    history: createWebHistory(),
    routes,
    linkExactActiveClass: 'active',
    linkActiveClass: ''
})

// 路由守卫
router.beforeEach((to, from, next) => {
    const token = localStorage.getItem('token')
    console.log('Current token:', token)
    console.log('Route requires auth:', to.meta.requiresAuth)

    if (to.meta.requiresAuth && !token) {
        console.log('Redirecting to login')
        next('/login')
    } else if (token && to.path === '/login') {
        console.log('Redirecting to home')
        next('/')
    } else {
        next()
    }
})

export default router 