<template>
  <div class="files-page">
    <!-- 顶部操作栏 -->
    <div class="action-bar glass-effect">
      <div class="left">
        <div class="button-group">
          <el-upload class="upload-btn" action="/api/upload" :show-file-list="false" :before-upload="handleBeforeUpload"
            :on-success="handleUploadSuccess">
            <el-button type="primary" :icon="Upload" v-tooltip="'上传新文件'">上传文件</el-button>
          </el-upload>
          <el-button :icon="FolderAdd" @click="createFolder" v-tooltip="'创建新文件夹'">新建文件夹</el-button>
        </div>
      </div>
      <div class="right">
        <el-input v-model="searchQuery" placeholder="搜索文件..." :prefix-icon="Search" clearable />
        <div class="view-mode-container">
          <el-tooltip content="网格视图" placement="top">
            <el-button :type="viewMode === 'grid' ? 'primary' : ''" @click="viewMode = 'grid'">
              <el-icon>
                <Grid />
              </el-icon>
            </el-button>
          </el-tooltip>
          <el-tooltip content="列表视图" placement="top">
            <el-button :type="viewMode === 'list' ? 'primary' : ''" @click="viewMode = 'list'">
              <el-icon>
                <List />
              </el-icon>
            </el-button>
          </el-tooltip>
        </div>
      </div>
    </div>

    <!-- 文件列表 -->
    <div class="files-container" :class="viewMode">
      <template v-if="viewMode === 'grid'">
        <div v-for="file in filteredFiles" :key="file.id" class="file-card glass-effect">
          <div class="file-icon">
            <el-icon :size="40">
              <component :is="getFileIcon(file.type)" />
            </el-icon>
          </div>
          <div class="file-info">
            <h4>{{ file.name }}</h4>
            <p>{{ file.size }} · {{ file.date }}</p>
          </div>
          <div class="file-actions">
            <el-dropdown trigger="click">
              <el-button type="text" :icon="More" />
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="downloadFile(file)">
                    <el-icon>
                      <Download />
                    </el-icon>下载
                  </el-dropdown-item>
                  <el-dropdown-item @click="renameFile(file)">
                    <el-icon>
                      <Edit />
                    </el-icon>重命名
                  </el-dropdown-item>
                  <el-dropdown-item divided @click="deleteFile(file)" class="danger">
                    <el-icon>
                      <Delete />
                    </el-icon>删除
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
        </div>
      </template>

      <el-table v-else :data="filteredFiles" style="width: 100%" class="glass-effect">
        <el-table-column label="文件名" min-width="300">
          <template #default="{ row }">
            <div class="file-name-cell">
              <el-icon>
                <component :is="getFileIcon(row.type)" />
              </el-icon>
              <span>{{ row.name }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column prop="size" label="大小" width="120" />
        <el-table-column prop="type" label="类型" width="120" />
        <el-table-column prop="date" label="修改日期" width="180" />
        <el-table-column label="操作" width="120" fixed="right">
          <template #default="{ row }">
            <el-button-group>
              <el-button type="primary" link :icon="Download" @click="downloadFile(row)" />
              <el-button type="primary" link :icon="Edit" @click="renameFile(row)" />
              <el-button type="danger" link :icon="Delete" @click="deleteFile(row)" />
            </el-button-group>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import {
  Upload,
  Download,
  Edit,
  Delete,
  More,
  Search,
  Grid,
  List,
  FolderAdd,
  Document,
  Picture,
  VideoCamera,
  Folder
} from '@element-plus/icons-vue'
import { ElMessage, ElMessageBox } from 'element-plus'

const viewMode = ref('grid')
const searchQuery = ref('')

// 模拟文件数据
const files = ref([
  {
    id: 1,
    name: '项目文档.pdf',
    size: '2.3MB',
    type: 'pdf',
    date: '2024-03-15 10:30'
  },
  {
    id: 2,
    name: '会议记录',
    size: '0KB',
    type: 'folder',
    date: '2024-03-14 15:20'
  },
  // 更多文件...
])

const filteredFiles = computed(() => {
  if (!searchQuery.value) return files.value
  return files.value.filter(file =>
    file.name.toLowerCase().includes(searchQuery.value.toLowerCase())
  )
})

const getFileIcon = (type) => {
  const icons = {
    pdf: Document,
    image: Picture,
    video: VideoCamera,
    folder: Folder
  }
  return icons[type] || Document
}

const handleBeforeUpload = (file) => {
  const isLt2M = file.size / 1024 / 1024 < 2
  if (!isLt2M) {
    ElMessage.error('上传文件大小不能超过 2MB!')
    return false
  }
  return true
}

const handleUploadSuccess = (response) => {
  ElMessage.success('文件上传成功')
  // 刷新文件列表
}

const createFolder = () => {
  ElMessageBox.prompt('请输入文件夹名称', '新建文件夹', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    inputValidator: (value) => {
      if (!value) {
        return '文件夹名称不能为空'
      }
      return true
    }
  }).then(({ value }) => {
    // 创建文件夹逻辑
    ElMessage.success(`创建文件夹 ${value} 成功`)
  })
}

const downloadFile = (file) => {
  ElMessage.success(`开始下载 ${file.name}`)
  // 实现文件下载逻辑
}

const renameFile = (file) => {
  ElMessageBox.prompt('请输入新的名称', '重命名', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    inputValue: file.name
  }).then(({ value }) => {
    // 重命名逻辑
    ElMessage.success(`重命名成功`)
  })
}

const deleteFile = (file) => {
  ElMessageBox.confirm(
    `确定要删除 ${file.name} 吗？此操作不可恢复`,
    '警告',
    {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning'
    }
  ).then(() => {
    // 删除文件逻辑
    ElMessage.success('删除成功')
  })
}
</script>

<style lang="scss" scoped>
.files-page {
  .action-bar {
    padding: 1rem;
    margin-bottom: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;

    .left {
      .button-group {
        display: flex;
        gap: 1rem; // 按钮之间的间距
        align-items: center;

        .upload-btn {
          display: inline-block; // 确保上传按钮内联显示
        }
      }
    }

    .right {
      display: flex;
      gap: 1rem;
      align-items: center;

      .el-input {
        width: 400px; // 增加搜索框宽度

        :deep(.el-input__wrapper) {
          background-color: var(--el-bg-color-overlay);
          border-color: var(--el-border-color);
        }
      }

      .view-mode-container {
        display: flex;
        gap: 0.5rem; // 按钮之间的间距

        .el-button {
          padding: 8px 15px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;

          .el-icon {
            margin: 0;
            font-size: 16px;
          }
        }
      }
    }
  }

  .files-container {
    &.grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 1rem;
    }

    .file-card {
      padding: 1rem;
      text-align: center;
      cursor: pointer;
      transition: all 0.3s;

      &:hover {
        transform: translateY(-2px);
      }

      .file-icon {
        margin-bottom: 0.5rem;
      }

      .file-info {
        h4 {
          margin: 0;
          font-size: 0.9rem;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        p {
          margin: 0.5rem 0 0;
          font-size: 0.8rem;
          color: var(--el-text-color-secondary);
        }
      }

      .file-actions {
        opacity: 0;
        transition: opacity 0.3s;
      }

      &:hover .file-actions {
        opacity: 1;
      }
    }
  }

  .file-name-cell {
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  :deep(.el-table) {
    --el-table-bg-color: var(--el-bg-color-overlay);
    --el-table-tr-bg-color: var(--el-bg-color-overlay);
    --el-table-header-bg-color: var(--el-bg-color);

    .el-table__header th {
      background-color: var(--el-bg-color);
      color: var(--el-text-color-primary);
    }
  }
}

// 修改 glass-effect 在暗色模式下的样式
:deep(.glass-effect) {
  .dark & {
    background: rgba(30, 30, 30, 0.7);
    border-color: var(--el-border-color-darker);
  }
}

// 添加工具提示的自定义样式
:deep(.el-tooltip__trigger) {
  outline: none;
}
</style>