<template>
    <div class="profile-page">
        <div class="profile-header glass-effect">
            <el-avatar :size="80">{{ userInfo.name.charAt(0).toUpperCase() }}</el-avatar>
            <div class="user-info">
                <h2>{{ userInfo.name }}</h2>
                <p>{{ userInfo.role }}</p>
            </div>
        </div>

        <div class="profile-content">
            <el-tabs>
                <el-tab-pane label="基本信息">
                    <div class="info-section glass-effect">
                        <el-form :model="userInfo" label-width="100px">
                            <el-form-item label="用户名">
                                <el-input v-model="userInfo.name" />
                            </el-form-item>
                            <el-form-item label="邮箱">
                                <el-input v-model="userInfo.email" />
                            </el-form-item>
                            <el-form-item label="角色">
                                <el-input v-model="userInfo.role" disabled />
                            </el-form-item>
                            <el-form-item label="注册时间">
                                <el-input v-model="userInfo.registerTime" disabled />
                            </el-form-item>
                            <el-form-item>
                                <el-button type="primary" @click="saveProfile">保存修改</el-button>
                            </el-form-item>
                        </el-form>
                    </div>
                </el-tab-pane>

                <el-tab-pane label="安全设置">
                    <div class="security-section glass-effect">
                        <div class="security-item">
                            <div class="item-header">
                                <h3>修改密码</h3>
                                <el-button link type="primary" @click="showChangePassword = true">修改</el-button>
                            </div>
                            <p class="description">定期修改密码可以提高账号安全性</p>
                        </div>
                        <div class="security-item">
                            <div class="item-header">
                                <h3>双因素认证</h3>
                                <el-switch v-model="security.twoFactor" />
                            </div>
                            <p class="description">启用双因素认证以增加账号安全性</p>
                        </div>
                    </div>
                </el-tab-pane>
            </el-tabs>
        </div>

        <!-- 修改密码对话框 -->
        <el-dialog v-model="showChangePassword" title="修改密码" width="400px">
            <el-form :model="passwordForm" label-width="100px">
                <el-form-item label="当前密码">
                    <el-input v-model="passwordForm.currentPassword" type="password" show-password />
                </el-form-item>
                <el-form-item label="新密码">
                    <el-input v-model="passwordForm.newPassword" type="password" show-password />
                </el-form-item>
                <el-form-item label="确认新密码">
                    <el-input v-model="passwordForm.confirmPassword" type="password" show-password />
                </el-form-item>
            </el-form>
            <template #footer>
                <el-button @click="showChangePassword = false">取消</el-button>
                <el-button type="primary" @click="changePassword">确认修改</el-button>
            </template>
        </el-dialog>
    </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage } from 'element-plus'

const userInfo = ref({
    name: '管理员',
    email: 'admin@example.com',
    role: '系统管理员',
    registerTime: '2024-01-01'
})

const security = ref({
    twoFactor: false
})

const showChangePassword = ref(false)
const passwordForm = ref({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
})

const saveProfile = () => {
    ElMessage.success('个人信息保存成功')
}

const changePassword = () => {
    if (passwordForm.value.newPassword !== passwordForm.value.confirmPassword) {
        ElMessage.error('两次输入的密码不一致')
        return
    }
    ElMessage.success('密码修改成功')
    showChangePassword.value = false
    passwordForm.value = {
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
    }
}
</script>

<style lang="scss" scoped>
.profile-page {
    .profile-header {
        padding: 2rem;
        display: flex;
        align-items: center;
        gap: 2rem;
        margin-bottom: 2rem;

        .user-info {
            h2 {
                margin: 0;
                font-size: 1.5rem;
                color: var(--el-text-color-primary);
            }

            p {
                margin: 0.5rem 0 0;
                color: var(--el-text-color-secondary);
            }
        }
    }

    .profile-content {
        .info-section {
            padding: 2rem;
        }

        .security-section {
            padding: 1rem;

            .security-item {
                padding: 1rem;
                border-bottom: 1px solid var(--el-border-color-lighter);

                &:last-child {
                    border-bottom: none;
                }

                .item-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: center;

                    h3 {
                        margin: 0;
                        font-size: 1rem;
                        color: var(--el-text-color-primary);
                    }
                }

                .description {
                    margin: 0.5rem 0 0;
                    font-size: 0.9rem;
                    color: var(--el-text-color-secondary);
                }
            }
        }
    }
}
</style>