<template>
  <div class="dashboard">
    <el-row :gutter="20">
      <el-col :span="6">
        <el-card shadow="hover" class="dashboard-card">
          <template #header>
            <div class="card-header">
              <span>总文件数</span>
            </div>
          </template>
          <div class="card-content">
            <el-statistic :value="156">
              <template #title>
                <div style="display: inline-flex; align-items: center">
                  文件总数
                  <el-icon style="margin-left: 4px">
                    <Document />
                  </el-icon>
                </div>
              </template>
            </el-statistic>
          </div>
        </el-card>
      </el-col>
      
      <el-col :span="6">
        <el-card shadow="hover" class="dashboard-card">
          <template #header>
            <div class="card-header">
              <span>存储空间</span>
            </div>
          </template>
          <div class="card-content">
            <el-progress type="dashboard" :percentage="68" />
            <div class="storage-info">
              <span>已用：6.8GB</span>
              <span>总共：10GB</span>
            </div>
          </div>
        </el-card>
      </el-col>
      
      <el-col :span="12">
        <el-card shadow="hover" class="dashboard-card">
          <template #header>
            <div class="card-header">
              <span>最近活动</span>
            </div>
          </template>
          <div class="card-content">
            <el-timeline>
              <el-timeline-item
                v-for="(activity, index) in activities"
                :key="index"
                :timestamp="activity.timestamp"
                :type="activity.type"
              >
                {{ activity.content }}
              </el-timeline-item>
            </el-timeline>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { Document } from '@element-plus/icons-vue'

const activities = ref([
  {
    content: '上传了文件 "项目方案.pdf"',
    timestamp: '2024-01-15 10:00',
    type: 'success'
  },
  {
    content: '更新了文件 "会议记录.docx"',
    timestamp: '2024-01-15 09:30',
    type: 'warning'
  },
  {
    content: '删除了文件 "旧版本.zip"',
    timestamp: '2024-01-15 09:00',
    type: 'danger'
  }
])
</script>

<style scoped>
.dashboard {
  padding: 20px;
}

.dashboard-card {
  margin-bottom: 20px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-content {
  text-align: center;
}

.storage-info {
  margin-top: 10px;
  display: flex;
  justify-content: space-around;
  color: #666;
  font-size: 14px;
}

:deep(.el-timeline-item__content) {
  color: var(--el-text-color-regular);
}
</style> 