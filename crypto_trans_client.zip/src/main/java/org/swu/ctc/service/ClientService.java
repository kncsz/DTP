package org.swu.ctc.service;

import org.springframework.core.io.Resource;
import com.alibaba.fastjson.JSONObject;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.swu.ctc.utils.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

@Service
public class ClientService {
    private static String clientPrivateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAKbNojYr8KlqKD/y" +
            "COd7QXu3e4TsrHd4sz3XgDYWEZZgYqIjVDcpcnlztwomgjMj9xSxdpyCc85GOGa0" +
            "lva1fNZpG6KXYS1xuFa9G7FRbaACoCL31TRv8t4TNkfQhQ7e2S7ZktqyUePWYLlz" +
            "u8hx5jXdriErRIx1jWK1q1NeEd3NAgMBAAECgYAws7Ob+4JeBLfRy9pbs/ovpCf1" +
            "bKEClQRIlyZBJHpoHKZPzt7k6D4bRfT4irvTMLoQmawXEGO9o3UOT8YQLHdRLitW" +
            "1CYKLy8k8ycyNpB/1L2vP+kHDzmM6Pr0IvkFgnbIFQmXeS5NBV+xOdlAYzuPFkCy" +
            "fUSOKdmt3F/Pbf9EhQJBANrF5Uaxmk7qGXfRV7tCT+f27eAWtYi2h/gJenLrmtke" +
            "Hg7SkgDiYHErJDns85va4cnhaAzAI1eSIHVaXh3JGXcCQQDDL9ns78LNDr/QuHN9" +
            "pmeDdlQfikeDKzW8dMcUIqGVX4WQJMptviZuf3cMvgm9+hDTVLvSePdTlA9YSCF4" +
            "VNPbAkEAvbe54XlpCKBIX7iiLRkPdGiV1qu614j7FqUZlAkvKrPMeywuQygNXHZ+" +
            "HuGWTIUfItQfSFdjDrEBBuPMFGZtdwJAV5N3xyyIjfMJM4AfKYhpN333HrOvhHX1" +
            "xVnsHOew8lGKnvMy9Gx11+xPISN/QYMa24dQQo5OAm0TOXwbsF73MwJAHzqaKZPs" +
            "EN08JunWDOKs3ZS+92maJIm1YGdYf5ipB8/Bm3wElnJsCiAeRqYKmPpAMlCZ5x+Z" +
            "AsuC1sjcp2r7xw=="; ;
    private static String serverPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCyGffCqoC1vCDLeBvjfuHdw4jo" +
            "hGvubOpQjEhhPzW1PbLSRKsNBLgj+eDGOiZE9BwmEwqy16sMOq0kMlhewTQlRrLJ" +
            "Nlw3L0iogs9WTIGm3el1SuZLyMnMksnV0NCsuq538cPMNppZRwARb7NXmpmh0KM7" +
            "9fJ/1xqnpo1tgRcv4wIDAQAB";

    public ResponseEntity<Resource> clientEncrypt(@RequestParam(value = "file", required = false) MultipartFile file) throws Exception {

        String fileContent = new String(file.getBytes(), StandardCharsets.UTF_8);
        String originalFilename = file.getOriginalFilename();

        // 生成RSA签名
        String sign = RSA.sign(fileContent, clientPrivateKey);

        // 创建一个包含文件内容和签名的JSON对象
        JSONObject json1 = new JSONObject();
        JSONObject json2 = new JSONObject();
        json1.put("attributes", originalFilename);
        json2.put("content", fileContent);
        json2.put("sign", sign);

        // 将JSON对象转换为字符串
        String info1 = json1.toJSONString();
        String info2 = json2.toJSONString();

        // 随机生成AES密钥
        String aesKey = SecureRandomUtil.getRandom(16);

        // AES加密数据
        String attributes = AES.encryptToBase64(ConvertUtil.stringToHexString(info1), aesKey);
        String data = AES.encryptToBase64(ConvertUtil.stringToHexString(info2), aesKey);

        // 使用RSA算法将商户自己随机生成的AESkey加密
        String encryptkey = RSA.encrypt(aesKey, serverPublicKey);
        System.out.println("加密成功");

        File encryptedFile = File.createTempFile("requestData", ".json");
        try (FileOutputStream fos = new FileOutputStream(encryptedFile)) {
            fos.write(attributes.getBytes(StandardCharsets.UTF_8));
            fos.write(data.getBytes(StandardCharsets.UTF_8));

            System.out.println("Data has been written to the temporary file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

        // 创建 Resource 对象
        Resource fileResource = new FileSystemResource(encryptedFile);

        // 设置响应头以便客户端知道如何处理文件下载
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", encryptedFile.getName());
        headers.set("X-Encrypt-Key", encryptkey); // 添加加密密钥到响应头

        return ResponseEntity.ok()
                .headers(headers)
                .body(fileResource);
    }


    /*
    public static Map<String, Object> uploadToServer(Req req) throws IOException {

        Map<String, Object> responseMap = new HashMap<>();
        try {
            // 假设getFileAttributes()和getFileContent()返回Base64编码的字符串
            String attributes = req.getFileAttributes();
            String data = req.getFileContent();
            String encryptkey = req.getEncryptkey();

            URL url = new URL("http://localhost:8082/api/fileManage/receive"); // 确保URL是正确的
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + BOUNDARY);

            try (OutputStream os = connection.getOutputStream();
                 PrintWriter writer = new PrintWriter(new OutputStreamWriter(os, "UTF-8"), true)) {
                //发送密钥部分
                writer.append("--" + BOUNDARY).append(CRLF);
                writer.append("Content-Disposition: form-data; name=\"encryptkey\"").append(CRLF);
                writer.append("Content-Type: application/base64; charset=UTF-8").append(CRLF);
                writer.append(CRLF).flush();
                writer.append(encryptkey).append(CRLF).flush();
                System.out.println("发送encryptkey");

                // 发送文件属性部分
                writer.append("--" + BOUNDARY).append(CRLF);
                writer.append("Content-Disposition: form-data; name=\"attributes\"").append(CRLF);
                writer.append("Content-Type: application/base64; charset=UTF-8").append(CRLF);
                writer.append(CRLF).flush();
                writer.append(attributes).append(CRLF).flush();
                System.out.println("发送文件属性");

                // 发送文件内容部分
                writer.append("--" + BOUNDARY).append(CRLF);
                writer.append("Content-Disposition: form-data; name=\"data\"").append(CRLF);
                writer.append("Content-Type: application/base64; charset=UTF-8").append(CRLF);
                writer.append(CRLF).flush();
                writer.append(data).append(CRLF).flush();
                System.out.println("发送文件内容");

                // 发送结束边界
                writer.append("--" + BOUNDARY + "--").append(CRLF).flush();
            }

            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                System.out.println("Data uploaded successfully");
                responseMap.put("status", "success");
            } else {
                System.out.println("Server returned non-OK status: " + responseCode);
                responseMap.put("status", "error");
                responseMap.put("httpStatus", responseCode);

                // 读取服务器返回的错误信息
                try (var errorStream = connection.getErrorStream()) {
                    if (errorStream != null) {
                        var errorMessage = new String(errorStream.readAllBytes(), "UTF-8");
                        System.out.println("Error message from server: " + errorMessage);
                        responseMap.put("errorMessage", errorMessage);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            responseMap.put("status", "error");
            responseMap.put("message", e.getMessage());
        }
        return responseMap;
    }
    */


    /*
    public static File clientEncrypt(byte[] videoContent, Req req) throws Exception{

        // 生成RSA签名
        String sign = RSA.sign(videoContent, clientPrivateKey);
        // 创建一个包含文件内容和签名的JSON对象
        JSONObject json1 = new JSONObject();
        JSONObject json2 = new JSONObject();
        json1.put("attributes", req.getFileName() + req.getFileType() + req.getFileSize());
        json2.put("content", videoContent);
        json2.put("sign", sign);

        // 将JSON对象转换为字符串
        String info1 = json1.toJSONString();
        String info2 = json2.toJSONString();
        // 随机生成AES密钥
        String aesKey = SecureRandomUtil.getRandom(16);

        // AES加密数据
        String attributes = AES.encryptToBase64(ConvertUtil.stringToHexString(info1), aesKey);
        String data = AES.encryptToBase64(ConvertUtil.stringToHexString(info2), aesKey);

        // 使用RSA算法将商户自己随机生成的AESkey加密
        String encryptkey = RSA.encrypt(aesKey, serverPublicKey);
        System.out.println("加密成功");

        String filePath = "output/requestData.json";
        File file = new File(filePath);

        try (FileWriter writer = new FileWriter(file)) {
            writer.write(attributes);
            writer.write(data);
            System.out.println("Data has been written to the file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("An error occurred while writing JSON data to the file.");
            return null; // 或者你可以抛出异常或以其他方式处理错误
        }

        return file;

        // 存储加密后的数据和加密密钥
        //req.setFileAttributes(attributes);
        //req.setFileContent(data);
        //req.setEncryptkey(encryptkey);
    }

     */

    /*
    public static Map<String, Object> beforeEncrypt (@RequestParam(value = "file", required = false) MultipartFile file, Req req) throws IOException {

        Map<String, Object> response = new HashMap<>();
        try {
            if (FileUtil.processSelectedFile(file, req) instanceof byte[]) {
                // 处理视频内容
                System.out.println("Video stream opened successfully.");
                clientEncrypt((byte[]) FileUtil.processSelectedFile(file, req), req);
            } else if (FileUtil.processSelectedFile(file, req) instanceof InputStream) {
                // 处理文件流
                System.out.println("File stream opened successfully.");
                clientEncrypt((InputStream) FileUtil.processSelectedFile(file, req), req);
            }
        } catch (Exception e) {
                e.printStackTrace();
        }

        response.put("success", true);
        response.put("message", "success to load the file" );
        return response;
    }
    */

}
