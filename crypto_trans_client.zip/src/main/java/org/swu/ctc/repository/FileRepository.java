package org.swu.ctc.repository;

import jakarta.transaction.Transactional;
import org.jetbrains.annotations.NotNull;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.swu.ctc.object.Req;

import java.util.List;

public interface FileRepository  {
    /*
    @Query("SELECT f FROM File f WHERE f.path = :path")

    List<Req> findByPath(@Param("path") String path);

    @NotNull
    @Transactional
    @Modifying
    @Override
    Req save(Req file);
    */
}
