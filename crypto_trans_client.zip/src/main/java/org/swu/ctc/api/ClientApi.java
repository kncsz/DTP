package org.swu.ctc.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.swu.ctc.service.ClientService;

@RestController
@CrossOrigin(origins="true")
public class ClientApi {
    @Autowired
    private ClientService clientservice;

    @PostMapping("/api/fileManage/fileEncryption")
    public ResponseEntity<Resource> clientEncrypt(@RequestParam(value = "file", required = false) MultipartFile file) {
        try {
            return clientservice.clientEncrypt(file);// 这里直接传递 file 参数
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
