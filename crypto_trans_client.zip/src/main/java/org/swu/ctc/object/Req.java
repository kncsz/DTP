package org.swu.ctc.object;

public class Req {

    private String encryptkey;
    private String fileType;
    private String fileName;
    private Long fileSize;
    protected String fileAttributes;
    protected String fileContent;

    public String getEncryptkey() {
        return encryptkey;
    }

    public void setEncryptkey(String encryptkey) {
        this.encryptkey = encryptkey;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Long getFileSize() {
        return fileSize;
    }

    public void setFileSize(Long fileSize) {
        this.fileSize = fileSize;
    }

    public String getFileAttributes() {
        return fileAttributes;
    }

    public void setFileAttributes(String fileAttributes) {
        this.fileAttributes = fileAttributes;
    }

    public String getFileContent() {
        return fileContent;
    }

    public void setFileContent(String fileContent) {
        this.fileContent = fileContent;
    }


}
